﻿using dvt_template.Shared.Core.Usecases;
using System;
using System.Collections.Generic;
using System.Text;
using dvt_template.Feature.User.ViewModel;


namespace dvt_template.Feature.User.Service
{
    public class ServiceCommand: ServiceCommandBase
    {
        public dvt_template.Shared.Core.DB.User CreateUser (UserViewModel user)
        {
            var User = new dvt_template.Shared.Core.DB.User
            {
                UserId = user.Id,
                FirstName = user.FirstName,
                LastName = user.LastName
            };
            dbcontext.User.Add(User);
            dbcontext.SaveChanges();

            return User;
        }
    }
}
